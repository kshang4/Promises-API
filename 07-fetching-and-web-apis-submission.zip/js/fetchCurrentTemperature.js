import fetch from "../include/fetch.js";
export function fetchCurrentTemperature(coords) {
    // TODO
    const searchURL = new URL("https://220.maxkuechen.com/currentTemperature/forecast");
    searchURL.searchParams.append("latitude", coords.lat.toString());
    searchURL.searchParams.append("longitude", coords.lon.toString());
    searchURL.searchParams.append("hourly", "temperature_2m");
    searchURL.searchParams.append("temperature_unit", "fahrenheit");
    return new Promise((resolve, reject) => {
        fetch(searchURL.toString())
            .then((res) => (res.ok ? res.json() : Promise.reject(new Error("No results found for query."))))
            .then((data) => resolve(data.hourly))
            .catch(error => reject(error));
    });
}
//# sourceMappingURL=fetchCurrentTemperature.js.map