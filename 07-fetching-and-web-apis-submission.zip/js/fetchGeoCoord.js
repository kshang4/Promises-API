import fetch from "../include/fetch.js";
export function fetchGeoCoord(query) {
    // TODO
    const home = new URL("https://220.maxkuechen.com/geoCoord/search");
    home.searchParams.append("q", query);
    return new Promise((res, rej) => {
        fetch(home)
            .then((res) => (res.ok ? res.json() : Promise.reject(new Error("No results found for query."))))
            .then((data) => Array.isArray(data) && data.length > 0
            ? res({ lat: Number.parseFloat(data[0].lat), lon: Number.parseFloat(data[0].lon) })
            : Promise.reject(new Error("No results found for query.")))
            .catch(err => rej(err));
    });
}
//# sourceMappingURL=fetchGeoCoord.js.map