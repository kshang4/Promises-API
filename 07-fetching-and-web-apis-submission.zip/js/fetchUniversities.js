import fetch from "../include/fetch.js";
export function fetchUniversities(query) {
    // TODO
    const url = new URL("http://220.maxkuechen.com/universities/search");
    url.searchParams.append("name", query);
    return new Promise((resolve, reject) => {
        fetch(url.toString())
            .then((response) => (response.ok ? response.json() : Promise.reject("No results found for query.")))
            .then(data => {
            if (Array.isArray(data) && data.length > 0) {
                const uniNames = data.map((university) => university.name);
                resolve(uniNames);
            }
            else {
                resolve([]);
            }
        })
            .catch(err => reject(err));
    });
}
//# sourceMappingURL=fetchUniversities.js.map